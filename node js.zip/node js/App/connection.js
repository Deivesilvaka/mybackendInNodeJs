
// Conectando ao banco de dados

const Sequelize = require("sequelize")

const sequelize = new Sequelize("cadastro", "root", "", {
    host: "localhost",
    dialect: "mysql"
})

/* Testar se esta conectado

sequelize.authenticate().then(() => {
    console.log("Conectado")
}).catch((err) => {
    console.log("falha ao se conectar: " + err)
}) */

const Postagem = sequelize.define("postagens", {
    titulo: {
        type: Sequelize.STRING
    },

    content: {
        type: Sequelize.TEXT
    }
})

const Usuario = sequelize.define("usuarios", {
    nome: {
        type: Sequelize.STRING
    },

    sobreNome: {
        type: Sequelize.STRING
    },

    idade: {
        type: Sequelize.INTEGER
    },

    email: {
        type: Sequelize.STRING
    }
})

//Postagem.sync({ force: true })

//Usuario.sync({ force: true })
