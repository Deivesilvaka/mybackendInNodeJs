
const dimi = function(a , b) {
  return a - b;
}

module.exports = dimi;
