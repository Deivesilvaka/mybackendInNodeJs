
const multi = function(a, b) {
  return a * b;
}

module.exports = multi;
