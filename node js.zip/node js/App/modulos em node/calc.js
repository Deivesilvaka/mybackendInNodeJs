
const somarFunc = require("./somar");
const dimiFunc = require("./dimi");
const divFunc = require("./div");
const multiFunc = require("./multi");


console.log("\nA soma de 1 e 2 é: " + somarFunc(1, 2));

console.log("\nA subtração de 1 e 2 é: " + dimiFunc(1, 2));

console.log("\nA divisão de 1 e 2 é: " + divFunc(1, 2));

console.log("\nA multiplicação de 2 e 3 é: " + multiFunc(2, 3));
