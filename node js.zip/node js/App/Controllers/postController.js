
const Post = require("../Models/Post")

module.exports = {
    async store(req, res) {
        await Post.create({
            titulo: req.body.titulo,
            conteudo: req.body.conteudo
        }).then(() => {
            res.redirect("/")
        }).catch((err) => {
            res.send("falha ao criar o post: " + err)
        })
    },

    async destroy(req, res) {
        await Post.destroy({ where: { "id": req.params.id } }).then(() => {
            console.log("Deletado com sucesso")
        }).catch((err) => {
            console.log("Postagem não existe: " + err)
        })
    }
}