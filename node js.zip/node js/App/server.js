
const express = require("express")
const app = express()
const handlebars = require("express-handlebars")
const bodyParser = require("body-parser")
const Post = require("./Models/Post")
const postController = require("./Controllers/postController")


//Config
    //Tamplate Engine
        app.engine("handlebars", handlebars({ defaultLayout: "main" }))
        app.set("view engine", "handlebars")

//Configurandi Body Parser

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())


//Rotas

app.get("/cad", (req, res) => {
    res.render("formulario")
})

app.get("/", (req, res) => {
    Post.findAll({ order: [["id", "DESC"]] }).then((posts) => {
        res.render("home", { posts: posts })
    })
})

app.post("/add", postController.store)
app.get("/delete/:id", postController.destroy)

app.listen(8081, function(){
    console.log("rodando em http://localhost:8081")
})